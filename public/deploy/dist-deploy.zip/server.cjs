var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "25mb" }));
  app.use(import_express.default.urlencoded({ extended: true, limit: "25mb" }));
  app.post("/api/ai-support", async (req, res) => {
    try {
      const { message, image, videoUrl, history, userContext } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey && apiKey !== "MY_GEMINI_API_KEY" && apiKey.trim().length > 10) {
        const candidateModels = ["gemini-3.7-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"];
        const ai = new import_genai.GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build"
            }
          }
        });
        const systemInstruction = `You are "RF SMM AI Live Support Assistant" (\u0986\u09B0\u098F\u09AB \u098F\u09B8\u098F\u09AE\u098F\u09AE \u09B2\u09BE\u0987\u09AD \u098F\u0986\u0987 \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u0985\u09CD\u09AF\u09BE\u09B8\u09BF\u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u09A8\u09CD\u099F) for "RF SMM PANEL BD", Bangladesh's #1 Social Media Marketing (SMM) service platform.
Always reply helpfully, courteously, and clearly in fluent Bengali (\u09AC\u09BE\u0982\u09B2\u09BE) or English (if the user asks in English).

Platform Knowledge & Details:
1. Platform Name: RF SMM PANEL BD (\u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09C7\u09B0 \u09AC\u09BF\u09B6\u09CD\u09AC\u09B8\u09CD\u09A4 \u0993 \u09E7 \u09A8\u09AE\u09CD\u09AC\u09B0 \u09B8\u09CB\u09B6\u09CD\u09AF\u09BE\u09B2 \u09AE\u09BF\u09A1\u09BF\u09DF\u09BE \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982 \u09AA\u09CD\u09AF\u09BE\u09A8\u09C7\u09B2)\u0964
2. Deposit / Add Funds:
   - Payment Methods: bKash (\u09AC\u09BF\u0995\u09BE\u09B6), Nagad (\u09A8\u0997\u09A6), Rocket (\u09B0\u0995\u09C7\u099F)\u0964
   - Minimum Deposit: \u09F320 (\u09AC\u09BE \u098F\u09A1\u09AE\u09BF\u09A8 \u09A8\u09BF\u09B0\u09CD\u09A7\u09BE\u09B0\u09BF\u09A4 \u09AA\u09B0\u09BF\u09AE\u09BE\u09A3)\u0964
   - Process: Go to "Add Funds" (\u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F), choose payment method, copy the given number, Send Money (\u09B8\u09C7\u09A8\u09CD\u09A1 \u09AE\u09BE\u09A8\u09BF) from personal bKash/Nagad/Rocket, then submit sender number and Transaction ID (TrxID).
   - Approval: 1-5 minutes automatic / verified instantly.
3. Orders & Services:
   - Categories: Facebook (Followers, Likes, Views, Watchtime), Instagram (Followers, Likes, Views), YouTube (Subscribers, Views, Watchtime), TikTok, Telegram, Twitter/X, Spotify, Discord, Website Traffic.
   - Process: Go to "New Order", select Category & Service, paste valid public link, enter quantity, click Confirm.
   - Speed: Super fast, automated 24/7.
4. Referral Program (\u09EB% \u09B2\u09BE\u0987\u09AB\u099F\u09BE\u0987\u09AE \u0995\u09CD\u09AF\u09BE\u09B6 \u09AC\u09CB\u09A8\u09BE\u09B8):
   - Every user gets a unique Referral Link / Code.
   - When a referred friend deposits money, the referrer instantly receives 5% cash commission deposited directly to their main balance.
5. Daily Tasks & Screenshot Rewards:
   - Users can complete free social tasks and submit screenshot proof to earn free balance.
6. Multimodal Inspection (Screenshots & Videos):
   - If the user provides a screenshot (bKash/Nagad receipt, order error, transaction slip), inspect the transaction ID, amount, and number carefully, explain what is seen, and guide them clearly.
   - If user shares a video link or attachment, acknowledge and provide helpful advice.
7. Human / Direct Admin Contact:
   - Telegram Support: https://t.me/RF2_SMM
   - WhatsApp Support: https://wa.me/8801342163841

User Context:
${userContext ? JSON.stringify(userContext) : "Standard SMM User"}

Guidelines:
- Give well-formatted, friendly, accurate responses with emojis, bullet points, and actionable steps.
- Always provide immediate clarity. If checking personal payment records or manual adjustments is required, advise them kindly and offer the WhatsApp / Telegram admin links.`;
        const contents = [];
        if (Array.isArray(history)) {
          for (const item of history.slice(-6)) {
            contents.push({
              role: item.role === "user" ? "user" : "model",
              parts: [{ text: item.text }]
            });
          }
        }
        const userParts = [];
        if (message && message.trim()) {
          userParts.push({ text: message });
        } else if (image) {
          userParts.push({ text: "\u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u098F\u0987 \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09B6\u099F / \u099B\u09AC\u09BF\u099F\u09BF \u09A6\u09C7\u0996\u09C7 \u0986\u09AE\u09BE\u0995\u09C7 \u09B8\u09BE\u09B9\u09BE\u09AF\u09CD\u09AF \u0995\u09B0\u09C1\u09A8\u0964" });
        }
        if (videoUrl) {
          userParts.push({ text: `[User attached video link: ${videoUrl}]` });
        }
        if (image) {
          try {
            if (typeof image === "string" && image.startsWith("data:")) {
              const matches = image.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
              if (matches && matches.length === 3) {
                userParts.push({
                  inlineData: {
                    mimeType: matches[1],
                    data: matches[2]
                  }
                });
              }
            } else if (image.mimeType && image.data) {
              userParts.push({
                inlineData: {
                  mimeType: image.mimeType,
                  data: image.data
                }
              });
            }
          } catch (imgErr) {
            console.warn("Image parse warning:", imgErr);
          }
        }
        if (userParts.length === 0) {
          userParts.push({ text: "Hello, need help" });
        }
        contents.push({
          role: "user",
          parts: userParts
        });
        for (const modelName of candidateModels) {
          try {
            const response = await ai.models.generateContent({
              model: modelName,
              contents,
              config: {
                systemInstruction,
                temperature: 0.7
              }
            });
            if (response && response.text && response.text.trim()) {
              return res.json({
                reply: response.text,
                source: "gemini",
                model: modelName
              });
            }
          } catch (modelErr) {
            console.warn(`Model ${modelName} attempt notice:`, modelErr.message || modelErr);
          }
        }
      }
      const lower = (message || "").toLowerCase();
      let reply = "";
      if (lower.includes("\u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F") || lower.includes("\u099F\u09BE\u0995\u09BE") || lower.includes("\u09AC\u09CD\u09AF\u09BE\u09B2\u09C7\u09A8\u09CD\u09B8") || lower.includes("\u09AC\u09BF\u0995\u09BE\u09B6") || lower.includes("\u09A8\u0997\u09A6") || lower.includes("\u09B0\u0995\u09C7\u099F") || lower.includes("deposit") || lower.includes("payment") || lower.includes("bkash") || lower.includes("nagad")) {
        reply = `\u{1F4B3} **\u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F \u0995\u09B0\u09BE\u09B0 \u09B8\u09B9\u099C \u09A8\u09BF\u09DF\u09AE:**
\u09E7. \u09A8\u09BF\u099A\u09C7\u09B0 \u09AE\u09C7\u09A8\u09C1 \u09A5\u09C7\u0995\u09C7 **"Add Funds" (\u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F)** \u0985\u09AA\u09B6\u09A8\u09C7 \u09AF\u09BE\u09A8\u0964
\u09E8. \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u099B\u09A8\u09CD\u09A6\u09C7\u09B0 \u09AE\u09C7\u09A5\u09A1 (**\u09AC\u09BF\u0995\u09BE\u09B6 / \u09A8\u0997\u09A6 / \u09B0\u0995\u09C7\u099F**) \u09B8\u09BF\u09B2\u09C7\u0995\u09CD\u099F \u0995\u09B0\u09C1\u09A8\u0964
\u09E9. \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09C7 \u09A6\u09C7\u0993\u09DF\u09BE \u09AA\u09BE\u09B0\u09CD\u09B8\u09CB\u09A8\u09BE\u09B2 \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0\u09C7 **Send Money (\u09B8\u09C7\u09A8\u09CD\u09A1 \u09AE\u09BE\u09A8\u09BF)** \u0995\u09B0\u09C1\u09A8 (\u09AE\u09BF\u09A8\u09BF\u09AE\u09BE\u09AE \u09E8\u09E6 \u099F\u09BE\u0995\u09BE)\u0964
\u09EA. \u09AF\u09C7 \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0 \u09A5\u09C7\u0995\u09C7 \u099F\u09BE\u0995\u09BE \u09AA\u09BE\u09A0\u09BF\u09DF\u09C7\u099B\u09C7\u09A8 \u09B8\u09C7\u0987 \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0 \u098F\u09AC\u0982 **TrxID (\u099F\u09CD\u09B0\u09BE\u09A8\u099C\u09C7\u0995\u09B6\u09A8 \u0986\u0987\u09A1\u09BF)** \u09B2\u09BF\u0996\u09C7 **"\u09AA\u09C7\u09AE\u09C7\u09A8\u09CD\u099F \u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4 \u0995\u09B0\u09C1\u09A8"** \u09AC\u09BE\u099F\u09A8\u09C7 \u099A\u09BE\u09AA\u09C1\u09A8\u0964
\u26A1 \u09E7-\u09E9 \u09AE\u09BF\u09A8\u09BF\u099F\u09C7\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u098F\u0995\u09BE\u0989\u09A8\u09CD\u099F\u09C7 \u09AC\u09CD\u09AF\u09BE\u09B2\u09C7\u09A8\u09CD\u09B8 \u09B8\u09CD\u09AC\u09DF\u0982\u0995\u09CD\u09B0\u09BF\u09DF\u09AD\u09BE\u09AC\u09C7 \u09AF\u09CB\u0997 \u09B9\u09DF\u09C7 \u09AF\u09BE\u09AC\u09C7!`;
      } else if (lower.includes("\u0985\u09B0\u09CD\u09A1\u09BE\u09B0") || lower.includes("order") || lower.includes("\u09A6\u09C7\u09B0\u09BF") || lower.includes("\u09AA\u09C7\u09A8\u09CD\u09A1\u09BF\u0982") || lower.includes("pending") || lower.includes("status") || lower.includes("\u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8") || lower.includes("service")) {
        reply = `\u{1F680} **\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09B8\u0982\u0995\u09CD\u09B0\u09BE\u09A8\u09CD\u09A4 \u09A4\u09A5\u09CD\u09AF \u0993 \u0997\u09BE\u0987\u09A1:**
\u2022 **\u09A8\u09A4\u09C1\u09A8 \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09A6\u09BF\u09A4\u09C7:** \u09B9\u09CB\u09AE\u09AA\u09C7\u099C\u09C7 \u0997\u09BF\u09DF\u09C7 Category \u0993 Service \u09B8\u09BF\u09B2\u09C7\u0995\u09CD\u099F \u0995\u09B0\u09C1\u09A8, \u09B2\u09BF\u0982\u0995 \u09A6\u09BF\u09A8 \u098F\u09AC\u0982 Quantity \u09AC\u09B8\u09BF\u09DF\u09C7 \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0995\u09A8\u09AB\u09BE\u09B0\u09CD\u09AE \u0995\u09B0\u09C1\u09A8\u0964
\u2022 **\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u099F\u09BE\u09B8 \u09A6\u09C7\u0996\u09A4\u09C7:** \u09A8\u09BF\u099A\u09C7\u09B0 **"Orders"** \u099F\u09CD\u09AF\u09BE\u09AC\u09C7 \u09AF\u09BE\u09A8\u0964 \u09B8\u09C7\u0996\u09BE\u09A8\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09AE\u09B8\u09CD\u09A4 \u0985\u09B0\u09CD\u09A1\u09BE\u09B0\u09C7\u09B0 \u09B2\u09BE\u0987\u09AD \u09AA\u09CD\u09B0\u0997\u09CD\u09B0\u09C7\u09B8 \u09A6\u09C7\u0996\u09A4\u09C7 \u09AA\u09BE\u09AC\u09C7\u09A8\u0964
\u2022 **\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u0995\u09A4\u0995\u09CD\u09B7\u09A3 \u09B2\u09BE\u0997\u09C7?** \u09EF\u09EB% \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u09E7-\u09EB \u09AE\u09BF\u09A8\u09BF\u099F\u09C7\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u0987\u09A8\u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u09A8\u09CD\u099F \u09B8\u09CD\u099F\u09BE\u09B0\u09CD\u099F \u09B9\u09DF\u09C7 \u09AF\u09BE\u09DF\u0964
\u2022 \u0995\u09CB\u09A8\u09CB \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0986\u099F\u0995\u09C7 \u09A5\u09BE\u0995\u09B2\u09C7 \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF \u0986\u09AE\u09BE\u09A6\u09C7\u09B0 \u098F\u09A1\u09AE\u09BF\u09A8 \u099F\u09C7\u09B2\u09BF\u0997\u09CD\u09B0\u09BE\u09AE (@RF2_SMM) \u09AC\u09BE \u09B9\u09CB\u09DF\u09BE\u099F\u09B8\u0985\u09CD\u09AF\u09BE\u09AA\u09C7 \u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8\u0964`;
      } else if (lower.includes("\u09B0\u09C7\u09AB\u09BE\u09B0") || lower.includes("refer") || lower.includes("\u09AC\u09CB\u09A8\u09BE\u09B8") || lower.includes("bonus") || lower.includes("\u0987\u09A8\u09AD\u09BE\u0987\u099F") || lower.includes("\u0995\u09AE\u09BF\u09B6\u09A8")) {
        reply = `\u{1F381} **\u09EB% \u09B0\u09C7\u09AB\u09BE\u09B0\u09C7\u09B2 \u09B2\u09BE\u0987\u09AB\u099F\u09BE\u0987\u09AE \u09AC\u09CB\u09A8\u09BE\u09B8:**
\u2022 \u09AA\u09CD\u09B0\u09CB\u09AB\u09BE\u0987\u09B2 \u09A5\u09C7\u0995\u09C7 **"\u09B0\u09C7\u09AB\u09BE\u09B0\u09C7\u09B2 \u0993 \u09EB% \u09AC\u09CB\u09A8\u09BE\u09B8"** \u0985\u09AA\u09B6\u09A8\u09C7 \u09AF\u09BE\u09A8\u0964
\u2022 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09BE\u09B0\u09CD\u09B8\u09CB\u09A8\u09BE\u09B2 \u09B0\u09C7\u09AB\u09BE\u09B0\u09C7\u09B2 \u09B2\u09BF\u0982\u0995 \u0995\u09AA\u09BF \u0995\u09B0\u09C7 \u09AC\u09A8\u09CD\u09A7\u09C1\u09A6\u09C7\u09B0 \u09B8\u09BE\u09A5\u09C7 \u09B6\u09C7\u09DF\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964
\u2022 \u0986\u09AA\u09A8\u09BE\u09B0 \u09B0\u09C7\u09AB\u09BE\u09B0\u09C7 \u099C\u09DF\u09C7\u09A8 \u0995\u09B0\u09BE \u09AC\u09A8\u09CD\u09A7\u09C1 \u09AF\u09A4\u09AC\u09BE\u09B0 \u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F \u0995\u09B0\u09AC\u09C7, \u09B8\u09BE\u09A5\u09C7 \u09B8\u09BE\u09A5\u09C7 \u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F\u09C7\u09B0 **\u09EB% \u0987\u09A8\u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u09A8\u09CD\u099F \u0995\u09CD\u09AF\u09BE\u09B6 \u0995\u09AE\u09BF\u09B6\u09A8** \u0986\u09AA\u09A8\u09BE\u09B0 \u09AE\u09C2\u09B2 \u09AC\u09CD\u09AF\u09BE\u09B2\u09C7\u09A8\u09CD\u09B8\u09C7 \u09AF\u09CB\u0997 \u09B9\u09AC\u09C7!`;
      } else if (lower.includes("\u099F\u09BE\u09B8\u09CD\u0995") || lower.includes("task") || lower.includes("\u09AB\u09CD\u09B0\u09BF") || lower.includes("free") || lower.includes("\u0987\u09A8\u0995\u09BE\u09AE") || lower.includes("\u09B0\u09BF\u0993\u09DF\u09BE\u09B0\u09CD\u09A1")) {
        reply = `\u{1F3C6} **\u09A1\u09C7\u0987\u09B2\u09BF \u099F\u09BE\u09B8\u09CD\u0995 \u0993 \u09AB\u09CD\u09B0\u09BF \u09B0\u09BF\u0993\u09DF\u09BE\u09B0\u09CD\u09A1\u09B8:**
\u2022 \u0986\u09AE\u09BE\u09A6\u09C7\u09B0 \u09AA\u09CD\u09B2\u09CD\u09AF\u09BE\u099F\u09AB\u09B0\u09CD\u09AE\u09C7 \u09B8\u09CB\u09B6\u09CD\u09AF\u09BE\u09B2 \u099F\u09BE\u09B8\u09CD\u0995 \u0995\u09AE\u09AA\u09CD\u09B2\u09BF\u099F \u0995\u09B0\u09C7 \u09AB\u09CD\u09B0\u09BF\u09A4\u09C7 \u099F\u09BE\u0995\u09BE \u0987\u09A8\u0995\u09BE\u09AE \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964
\u2022 \u099F\u09BE\u09B8\u09CD\u0995 \u0985\u09AA\u09B6\u09A8\u09C7 \u0997\u09BF\u09DF\u09C7 \u099F\u09BE\u09B8\u09CD\u0995 \u09A8\u09BF\u09B0\u09CD\u09A6\u09C7\u09B6\u09A8\u09BE \u0985\u09A8\u09C1\u09AF\u09BE\u09DF\u09C0 \u0995\u09BE\u099C \u0995\u09B0\u09C7 \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09B6\u099F \u0993 \u0987\u0989\u099C\u09BE\u09B0\u09A8\u09C7\u09AE \u099C\u09AE\u09BE \u09A6\u09BF\u09A8\u0964 \u098F\u09A1\u09AE\u09BF\u09A8 \u09AD\u09C7\u09B0\u09BF\u09AB\u09BE\u0987 \u0995\u09B0\u09B2\u09C7\u0987 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AC\u09CD\u09AF\u09BE\u09B2\u09C7\u09A8\u09CD\u09B8\u09C7 \u099F\u09BE\u0995\u09BE \u09AF\u09CB\u0997 \u09B9\u09AC\u09C7!`;
      } else if (lower.includes("\u09AA\u09BE\u09B8\u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1") || lower.includes("password") || lower.includes("\u09B2\u0997\u0987\u09A8") || lower.includes("login") || lower.includes("\u0987\u0989\u099C\u09BE\u09B0\u09A8\u09C7\u09AE") || lower.includes("username")) {
        reply = `\u{1F511} **\u09AA\u09BE\u09B8\u0993\u09DF\u09BE\u09B0\u09CD\u09A1 \u0993 \u0985\u09CD\u09AF\u09BE\u0995\u09BE\u0989\u09A8\u09CD\u099F \u09A8\u09BF\u09B0\u09BE\u09AA\u09A4\u09CD\u09A4\u09BE:**
\u2022 \u09AA\u09CD\u09B0\u09CB\u09AB\u09BE\u0987\u09B2 \u099F\u09CD\u09AF\u09BE\u09AC\u09C7 \u0997\u09BF\u09DF\u09C7 **"\u09AA\u09BE\u09B8\u0993\u09DF\u09BE\u09B0\u09CD\u09A1 \u09AA\u09B0\u09BF\u09AC\u09B0\u09CD\u09A4\u09A8"** \u09AC\u09BE **"\u0987\u0989\u099C\u09BE\u09B0 \u09A8\u09BE\u09AE \u09AA\u09B0\u09BF\u09AC\u09B0\u09CD\u09A4\u09A8"** \u09AC\u09BE\u099F\u09A8\u09C7 \u0995\u09CD\u09B2\u09BF\u0995 \u0995\u09B0\u09C7 \u098F\u0995\u09BE\u0989\u09A8\u09CD\u099F \u0986\u09AA\u09A1\u09C7\u099F \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u09A8\u0964
\u2022 \u098F\u0995\u09BE\u0989\u09A8\u09CD\u099F\u09C7 \u0995\u09CB\u09A8\u09CB \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE \u09B9\u09B2\u09C7 \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF \u098F\u09A1\u09AE\u09BF\u09A8 \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F\u09C7 \u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8\u0964`;
      } else if (lower.includes("\u098F\u09A1\u09AE\u09BF\u09A8") || lower.includes("admin") || lower.includes("\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997") || lower.includes("human") || lower.includes("whatsapp") || lower.includes("telegram") || lower.includes("\u0995\u09B2") || lower.includes("help")) {
        reply = `\u{1F468}\u200D\u{1F4BC} **\u098F\u09A1\u09AE\u09BF\u09A8 \u0993 \u09B9\u09BF\u0989\u09AE\u09CD\u09AF\u09BE\u09A8 \u09B2\u09BE\u0987\u09AD \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F:**
\u2022 \u{1F4F1} **WhatsApp Support:** +8801342163841
\u2022 \u2708\uFE0F **Telegram Admin:** @RF2_SMM
\u09E8\u09EA/\u09ED \u0986\u09AE\u09BE\u09A6\u09C7\u09B0 \u099F\u09BF\u09AE \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09B9\u09BE\u09DF\u09A4\u09BE\u09DF \u09A8\u09BF\u09DF\u09CB\u099C\u09BF\u09A4!`;
      } else {
        reply = `\u{1F44B} \u09B8\u09CD\u09AC\u09BE\u0997\u09A4\u09AE! \u0986\u09AE\u09BF **RF SMM \u09B2\u09BE\u0987\u09AD AI \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u09B8\u09B9\u0995\u09BE\u09B0\u09C0**\u0964 
\u0986\u09AE\u09BF \u0986\u09AA\u09A8\u09BE\u0995\u09C7 \u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F, \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u099F\u09CD\u09B0\u09CD\u09AF\u09BE\u0995\u09BF\u0982, \u09B8\u09CB\u09B6\u09CD\u09AF\u09BE\u09B2 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u09AA\u09CD\u09AF\u09BE\u0995\u09C7\u099C, \u09EB% \u09B0\u09C7\u09AB\u09BE\u09B0\u09C7\u09B2 \u09AC\u09CB\u09A8\u09BE\u09B8 \u098F\u09AC\u0982 \u0985\u09CD\u09AF\u09BE\u0995\u09BE\u0989\u09A8\u09CD\u099F \u09B8\u0982\u0995\u09CD\u09B0\u09BE\u09A8\u09CD\u09A4 \u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u09AC\u09BF\u09B7\u09DF\u09C7 \u09B8\u09BE\u09B0\u09CD\u09AC\u0995\u09CD\u09B7\u09A3\u09BF\u0995 \u09B8\u09BE\u09B9\u09BE\u09AF\u09CD\u09AF \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09BF\u0964 

\u{1F4A1} **\u0986\u09AA\u09A8\u09BF \u09A8\u09BF\u099A\u09C7\u09B0 \u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u09AC\u09BF\u09B7\u09DF\u09C7 \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u09A8:**
\u09E7. \u{1F4B3} \u09AC\u09BF\u0995\u09BE\u09B6/\u09A8\u0997\u09A6/\u09B0\u0995\u09C7\u099F\u09C7 \u0995\u09C0\u09AD\u09BE\u09AC\u09C7 \u09A1\u09BF\u09AA\u09CB\u099C\u09BF\u099F \u0995\u09B0\u09AC?
\u09E8. \u{1F680} \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09A6\u09BF\u09A4\u09C7 \u0995\u09C0 \u0995\u09C0 \u09B2\u09BE\u0997\u09AC\u09C7 \u0993 \u0995\u09A4\u0995\u09CD\u09B7\u09A3 \u09B8\u09AE\u09DF \u09B2\u09BE\u0997\u09C7?
\u09E9. \u{1F381} \u09EB% \u09B0\u09C7\u09AB\u09BE\u09B0\u09C7\u09B2 \u09AC\u09CB\u09A8\u09BE\u09B8 \u0995\u09C0\u09AD\u09BE\u09AC\u09C7 \u09AC\u09CD\u09AF\u09BE\u09B2\u09C7\u09A8\u09CD\u09B8\u09C7 \u09AF\u09CB\u0997 \u09B9\u09DF?
\u09EA. \u{1F468}\u200D\u{1F4BC} \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF \u098F\u09A1\u09AE\u09BF\u09A8\u09C7\u09B0 \u09B8\u09BE\u09A5\u09C7 \u0995\u09C0\u09AD\u09BE\u09AC\u09C7 \u0995\u09A5\u09BE \u09AC\u09B2\u09AC?`;
      }
      return res.json({
        reply,
        source: "smart_engine"
      });
    } catch (err) {
      console.error("AI Support Handler Error:", err);
      return res.status(500).json({
        error: "Failed to process AI response",
        details: err.message
      });
    }
  });
  app.post("/api/telegram/order-notify", async (req, res) => {
    try {
      const {
        orderId,
        apiOrderId,
        serviceName,
        category,
        quantity,
        cost,
        link,
        userName,
        userEmail,
        status,
        createdAt,
        siteLogo,
        botToken: customBotToken,
        channels: customChannels,
        enabled,
        miniAppUrl: customMiniAppUrl
      } = req.body;
      if (enabled === false) {
        return res.json({
          success: true,
          skipped: true,
          message: "Telegram order notifications are currently disabled.",
          results: []
        });
      }
      const botToken = customBotToken && typeof customBotToken === "string" && customBotToken.trim() || process.env.TELEGRAM_BOT_TOKEN || "8417495766:AAEupqJEr6_IyvOcGXhhdWStj95khUdr8MU";
      let targetChannels = [];
      if (Array.isArray(customChannels) && customChannels.length > 0) {
        targetChannels = customChannels.map((c) => String(c).trim()).filter((c) => c.length > 0);
      } else if (typeof customChannels === "string" && customChannels.trim()) {
        targetChannels = customChannels.split(/[\n,;]+/).map((c) => c.trim()).filter((c) => c.length > 0);
      }
      if (targetChannels.length === 0) {
        targetChannels = ["@RF2_SMM", "@FARJU_SMM_PANAL"];
      }
      targetChannels = targetChannels.map((c) => {
        if (!c.startsWith("@") && !c.startsWith("-") && !c.startsWith("https://t.me/")) {
          if (/^[a-zA-Z0-9_]+$/.test(c)) {
            return "@" + c;
          }
        }
        if (c.startsWith("https://t.me/")) {
          return "@" + c.replace("https://t.me/", "").replace("/", "");
        }
        return c;
      });
      const dateStr = createdAt ? new Date(createdAt).toLocaleString("en-US", {
        timeZone: "Asia/Dhaka",
        dateStyle: "medium",
        timeStyle: "short"
      }) : (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
        timeZone: "Asia/Dhaka",
        dateStyle: "medium",
        timeStyle: "short"
      });
      const escapeHtml = (str) => String(str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const safeOrderId = escapeHtml(orderId || "ORD-" + Math.floor(1e5 + Math.random() * 9e5));
      const safeApiId = apiOrderId ? ` (SMM ID: <code>#${escapeHtml(apiOrderId)}</code>)` : "";
      const safeService = escapeHtml(serviceName || "Social Media Service");
      const safeCat = escapeHtml(category || "SMM Package");
      const safeLink = escapeHtml(link || "https://t.me/RF2_SMM");
      const safeQty = Number(quantity || 0).toLocaleString();
      const safeCost = Number(cost || 0).toFixed(2);
      const safeUser = escapeHtml(userName || (userEmail ? userEmail.split("@")[0] : "Verified Client"));
      const safeStatus = escapeHtml(status || "Processing \u26A1");
      const captionStyle = req.body.captionStyle || "vip";
      const customHeader = req.body.customHeader ? escapeHtml(req.body.customHeader) : "";
      const customFooter = req.body.customFooter ? escapeHtml(req.body.customFooter) : "";
      let stylishCaption = "";
      if (captionStyle === "minimal") {
        stylishCaption = `\u{1F4E6} <b>Order #${safeOrderId}</b> \u2022 <code>SUCCESS</code>
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u2022 <b>Service:</b> <b>${safeService}</b>
\u2022 <b>Target:</b> <code>${safeLink}</code>
\u2022 <b>Quantity:</b> <b>${safeQty}</b> | <b>\u09F3${safeCost}</b>
\u2022 <b>Client:</b> <code>${safeUser}</code>
\u2022 <b>Status:</b> <b>${safeStatus}</b>
\u2022 <b>Time:</b> <code>${dateStr}</code>
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A1 <i>${customFooter || "RF SMM Automated System"}</i>`;
      } else if (captionStyle === "cyber") {
        stylishCaption = `\u26A1 <b>DISPATCH: ORDER #${safeOrderId}</b>
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
[SERVICE] <b>${safeService}</b>
[TARGET]  <code>${safeLink}</code>
[AMOUNT]  <b>${safeQty} Units</b> (\u09F3${safeCost})
[CLIENT]  <code>${safeUser}</code>
[STATUS]  \u26A1 <b>${safeStatus}</b>
[TIME]    <code>${dateStr}</code>
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u26A1 <i>${customFooter || "RF SMM PANEL \u2022 Instant Fast Delivery"}</i>`;
      } else {
        const headerTitle = customHeader || "\u26A1 <b>NEW ORDER PROCESSED</b> \u26A1";
        stylishCaption = `${headerTitle}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F194} <b>Order ID  :</b> <code>#${safeOrderId}</code>${safeApiId}
\u{1F4E6} <b>Service   :</b> <b>${safeService}</b>
\u{1F3F7}\uFE0F <b>Category  :</b> <code>${safeCat}</code>
\u{1F3AF} <b>Target    :</b> <code>${safeLink}</code>
\u{1F522} <b>Quantity  :</b> <b>${safeQty}</b>
\u{1F4B0} <b>Price     :</b> <b>\u09F3${safeCost}</b>
\u{1F464} <b>Client    :</b> <code>${safeUser}</code>
\u26A1 <b>Status    :</b> <b>${safeStatus}</b>
\u{1F4C5} <b>Time (BD) :</b> <code>${dateStr}</code>
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F451} <i>${customFooter || "RF SMM PANEL \u2022 Instant Fast Delivery"}</i>`;
      }
      const primaryChannelUrl = targetChannels[0]?.startsWith("@") ? `https://t.me/${targetChannels[0].replace("@", "")}` : "https://t.me/RF2_SMM";
      const miniAppUrl = customMiniAppUrl && typeof customMiniAppUrl === "string" && customMiniAppUrl.trim() || process.env.TELEGRAM_MINI_APP_URL || "https://t.me/RF_SMM_PRO_BOT?startapp=8479465879";
      const inlineKeyboard = {
        inline_keyboard: [
          [
            { text: "\u{1F680} \u0993\u09AA\u09C7\u09A8 Mini App (\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8)", url: miniAppUrl }
          ],
          [
            { text: "\u{1F4AC} WhatsApp \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F", url: "https://wa.me/8801342163841" },
            { text: "\u{1F4E2} \u0985\u09AB\u09BF\u09B8\u09BF\u09DF\u09BE\u09B2 \u099A\u09CD\u09AF\u09BE\u09A8\u09C7\u09B2", url: primaryChannelUrl }
          ]
        ]
      };
      let isBase64 = false;
      let base64Buffer = null;
      let mimeType = "image/png";
      let photoUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80";
      if (siteLogo && typeof siteLogo === "string") {
        if (siteLogo.startsWith("http://") || siteLogo.startsWith("https://")) {
          photoUrl = siteLogo;
        } else if (siteLogo.startsWith("data:image/")) {
          try {
            const match = siteLogo.match(/^data:(image\/[a-zA-Z0-9\+\-]+);base64,(.+)$/);
            if (match) {
              mimeType = match[1];
              base64Buffer = Buffer.from(match[2], "base64");
              isBase64 = true;
            }
          } catch (b64Err) {
            console.error("Base64 parsing error:", b64Err);
          }
        }
      }
      const results = [];
      for (const channel of targetChannels) {
        try {
          let photoJson = null;
          if (isBase64 && base64Buffer) {
            try {
              const formData = new FormData();
              formData.append("chat_id", channel);
              formData.append("caption", stylishCaption);
              formData.append("parse_mode", "HTML");
              formData.append("reply_markup", JSON.stringify(inlineKeyboard));
              const blob = new Blob([base64Buffer], { type: mimeType });
              formData.append("photo", blob, `logo.${mimeType.split("/")[1] || "png"}`);
              const tgPhotoRes = await fetch(
                `https://api.telegram.org/bot${botToken}/sendPhoto`,
                {
                  method: "POST",
                  body: formData
                }
              );
              photoJson = await tgPhotoRes.json();
            } catch (formErr) {
              console.warn("FormData send error, trying URL fallback:", formErr);
            }
          }
          if (!photoJson || !photoJson.ok) {
            const photoPayload = {
              chat_id: channel,
              photo: photoUrl,
              caption: stylishCaption,
              parse_mode: "HTML",
              reply_markup: inlineKeyboard
            };
            const tgPhotoRes = await fetch(
              `https://api.telegram.org/bot${botToken}/sendPhoto`,
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(photoPayload)
              }
            );
            photoJson = await tgPhotoRes.json();
          }
          if (photoJson.ok) {
            results.push({ channel, success: true, mode: "photo" });
          } else {
            const msgPayload = {
              chat_id: channel,
              text: stylishCaption,
              parse_mode: "HTML",
              reply_markup: inlineKeyboard,
              disable_web_page_preview: false
            };
            const tgMsgRes = await fetch(
              `https://api.telegram.org/bot${botToken}/sendMessage`,
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(msgPayload)
              }
            );
            const msgJson = await tgMsgRes.json();
            results.push({ channel, success: !!msgJson.ok, mode: "message", error: msgJson.description });
          }
        } catch (chanErr) {
          console.error(`Error sending telegram notify to ${channel}:`, chanErr);
          results.push({ channel, success: false, error: chanErr.message });
        }
      }
      const hasSuccess = results.some((r) => r.success);
      return res.json({ success: hasSuccess, results, totalChannels: targetChannels.length });
    } catch (err) {
      console.error("Telegram Order Notify API Error:", err);
      return res.json({ success: false, error: err.message, results: [] });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
